""" This module loads the entire VTK library into its namespace.  It
also allows one to use specific packages inside the vtk directory.."""

from __future__ import absolute_import

# --------------------------------------
from .vtkCommonCore import *
from .vtkCommonMath import *
from .vtkCommonTransforms import *
from .vtkCommonDataModel import *
from .vtkCommonExecutionModel import *
from .vtkCommonMisc import *
from .vtkFiltersCore import *
from .vtkFiltersGeneral import *
from .vtkFiltersHyperTree import *
from .vtkRenderingCore import *
from .vtkRenderingFreeType import *
from .vtkRenderingLabel import *
from .vtkRenderingImage import *
from .vtkRenderingContext2D import *
from .vtkIOCore import *
from .vtkImagingCore import *
from .vtkIOImage import *
from .vtkRenderingHyperTreeGrid import *
from .vtkRenderingUI import *
from .vtkRenderingOpenGL2 import *
from .vtkRenderingContextOpenGL2 import *
from .vtkImagingMath import *
from .vtkRenderingVolume import *
from .vtkRenderingVolumeOpenGL2 import *
from .vtkIOPLY import *
from .vtkFiltersCellGrid import *
from .vtkIOCellGrid import *
from .vtkIOLegacy import *
from .vtkIOXMLParser import *
from .vtkIOXML import *
from .vtkIOInfovis import *
from .vtkRenderingSceneGraph import *
from .vtkRenderingVtkJS import *
from .vtkIOExport import *
from .vtkDomainsChemistry import *
from .vtkIOGeometry import *
from .vtkFiltersVerdict import *
from .vtkInteractionImage import *
from .vtkImagingStencil import *
from .vtkImagingStatistics import *
from .vtkImagingGeneral import *
from .vtkImagingMorphological import *
from .vtkIOSQL import *
from .vtkFiltersSources import *
from .vtkInteractionWidgets import *
from .vtkRenderingAnnotation import *
from .vtkInteractionStyle import *
from .vtkImagingHybrid import *
from .vtkImagingColor import *
from .vtkFiltersModeling import *
from .vtkFiltersPoints import *
from .vtkCommonComputationalGeometry import *
from .vtkFiltersFlowPaths import *
from .vtkCommonSystem import *
from .vtkParallelCore import *
from .vtkFiltersExtraction import *
from .vtkFiltersGeometry import *
from .vtkFiltersHybrid import *
from .vtkFiltersTexture import *
from .vtkFiltersParallel import *
from .vtkCommonColor import *
from .vtkChartsCore import *
from .vtkImagingSources import *
from .vtkInfovisCore import *
from .vtkFiltersStatistics import *
from .vtkFiltersReduction import *


# useful macro for getting type names
from .util.vtkConstants import vtkImageScalarTypeNameMacro

# import convenience decorators
from .util.misc import calldata_type

# import the vtkVariant helpers
from .util.vtkVariant import *
