available_kits = [ 'mrml', 'vtkAddon', 'vtkSegmentationCore', 'slicerwebcore', 'logic' ]
