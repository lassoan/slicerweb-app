"""This module loads all the classes from the SlicerWebCore library into its namespace."""
import vtk  # noqa: F401
from SlicerWebCorePython import *  # noqa: F401,F403
del vtk
