"""Qt-free equivalent of qSlicerModuleManager / qSlicerModuleFactoryManager.

Three kinds of modules are supported, mirroring desktop Slicer:

- **Loadable (C++) modules**: their MRML, Logic, VTKWidgets and MRMLDM libraries are the same C++
  code as in desktop Slicer. The Qt part (``qSlicer<Name>Module``) is replaced by a small descriptor
  (:class:`LoadableModuleDescriptor`) that creates the logic and performs the non-GUI setup that the
  Qt module class does in desktop Slicer. The GUI is provided by a web widget.
- **Scripted (Python) modules**: ``ScriptedLoadableModule`` subclasses defined in ``.py`` files,
  loaded unchanged. Their widgets use the ``qt``/``ctk`` compatibility layer or a web widget.
- **Extension modules**: loadable or scripted modules shipped in extension wheels, registered through
  the ``slicerweb.modules`` entry point group or by adding a module path.

Each module is available as ``slicer.modules.<lowercasename>`` with the familiar API
(``logic()``, ``name``, ``title``, ``categories``, ``path``, ``widgetRepresentation()``).
"""

import builtins
import glob
import importlib
import importlib.util
import logging
import os
import sys

from . import host

logger = logging.getLogger("slicerweb.modules")


class ModuleBase:
    """Common API of loadable and scripted modules (subset of qSlicerAbstractCoreModule)."""

    def __init__(self, name, title=None, categories=None, dependencies=None, path="", hidden=False,
                 helpText="", acknowledgementText="", contributors=None, webWidget=None, icon=None,
                 extension=None):
        self.name = name
        self.title = title or name
        self.categories = list(categories or [])
        self.dependencies = list(dependencies or [])
        self.path = path
        self.hidden = hidden
        self.helpText = helpText
        self.acknowledgementText = acknowledgementText
        self.contributors = list(contributors or [])
        self.webWidget = webWidget
        self.icon = icon
        self.extension = extension  # name of the extension the module came from, or None
        self._logic = None
        self._widget = None
        self._app = None

    # qSlicerAbstractCoreModule API
    def logic(self):
        return self._logic

    def isHidden(self):
        return self.hidden

    def hasTest(self):
        """The module provides a self test (<Name>Test class), which "Reload and Test" runs."""
        return False

    def widgetRepresentation(self):
        return self._widget

    def createNewWidgetRepresentation(self):
        return None

    def summary(self):
        return {
            "name": self.name,
            "title": self.title,
            "categories": self.categories,
            "dependencies": self.dependencies,
            "hidden": self.hidden,
            "kind": self.kind,
            "helpText": self.helpText,
            "acknowledgementText": self.acknowledgementText,
            "contributors": self.contributors,
            "webWidget": self.webWidget,
            "hasTest": self.hasTest(),
            "icon": self.icon or module_icon(self.name, self.path),
            "path": self.path,
            "extension": self.extension or extension_of_path(self.path),
        }

    def __repr__(self):
        return f"<{type(self).__name__} {self.name}>"


class LoadableModuleDescriptor(ModuleBase):
    """A C++ loadable module (Qt module class replaced by this descriptor)."""

    kind = "loadable"

    def __init__(self, name, logicClass=None, setup=None, **kwargs):
        super().__init__(name, **kwargs)
        self.logicClass = logicClass
        self._setup = setup

    def initialize(self, app):
        """Same as qSlicerAbstractCoreModule::initialize: create logic, then setup()."""
        import slicer

        self._app = app
        if self.logicClass:
            cls = getattr(slicer, self.logicClass, None)
            if cls is None and self.logicClass.endswith("Logic"):
                # A module's logic is usually vtkSlicer<Name>Logic, but not always
                # (vtkSlicerIsodoseModuleLogic): the other spelling, before giving up.
                cls = getattr(slicer, self.logicClass[:-len("Logic")] + "ModuleLogic", None)
            if cls is None:
                raise RuntimeError(f"Logic class {self.logicClass} of module {self.name} is not available")
            logic = cls()
            if isinstance(logic, slicer.vtkSlicerModuleLogic):
                logic.SetModuleShareDirectory(module_share_directory(app, self.name))
            logic.SetMRMLApplicationLogic(app.applicationLogic())
            if self._setup is not None and getattr(self._setup, "before_scene", False):
                self._setup(self, app, logic)
            logic.SetMRMLScene(app.mrmlScene())
            app.applicationLogic().SetModuleLogic(self.name, logic)
            self._logic = logic
        if self._setup is not None and not getattr(self._setup, "before_scene", False):
            self._setup(self, app, self._logic)


class ScriptedModule(ModuleBase):
    """A Python scripted module (qSlicerScriptedLoadableModule equivalent)."""

    kind = "scripted"

    def __init__(self, name, path, pythonModule, instance, **kwargs):
        parent_info = _parent_info(instance)
        kwargs.setdefault("title", parent_info.get("title"))
        kwargs.setdefault("categories", parent_info.get("categories"))
        kwargs.setdefault("dependencies", parent_info.get("dependencies"))
        kwargs.setdefault("hidden", parent_info.get("hidden", False))
        kwargs.setdefault("helpText", parent_info.get("helpText", ""))
        kwargs.setdefault("acknowledgementText", parent_info.get("acknowledgementText", ""))
        kwargs.setdefault("contributors", parent_info.get("contributors"))
        kwargs.setdefault("webWidget", getattr(instance, "webWidget", None))
        super().__init__(name, path=path, **kwargs)
        self.pythonModule = pythonModule
        self.instance = instance

    def initialize(self, app):
        self._app = app
        # ScriptedLoadableModule does not create a logic automatically (qSlicerScriptedLoadableModule
        # creates an empty vtkSlicerScriptedLoadableModuleLogic); logic() returns the widget's logic.
        if hasattr(self.instance, "setup"):
            pass
        self.registerIO()

    def registerIO(self):
        """Register the reader and writer the module brings, if it has any.

        Same as qSlicerScriptedLoadableModule::registerIO: a module that defines a class named
        <ModuleName>FileReader or <ModuleName>FileWriter has it added to the list of readers and
        writers, so that its files can be opened like any other (see slicerweb.io_scripted).
        """
        from . import io_scripted

        try:
            io_scripted.register_module_handlers(self.name, self.pythonModule)
        except Exception:
            logger.exception("The readers and writers of module %s could not be registered", self.name)

    def unregisterIO(self):
        from . import io_scripted

        try:
            io_scripted.unregister_module_handlers(self.name)
        except Exception:
            logger.debug("The readers of module %s could not be taken away", self.name, exc_info=True)

    def hasTest(self):
        return getattr(self.pythonModule, self.name + "Test", None) is not None

    def widgetRepresentation(self):
        """The module's widget, created when it is first needed (as qSlicerScriptedLoadableModule does)."""
        if self._widget is None:
            create_scripted_module_widget(self.name)
        return self._widget

    def createNewWidgetRepresentation(self):
        return self.widgetRepresentation()

    def logic(self):
        widget = self._widget
        if widget is not None and hasattr(widget, "logic"):
            return widget.logic
        logic_cls = getattr(self.pythonModule, self.name + "Logic", None)
        if self._logic is None and logic_cls is not None:
            try:
                self._logic = logic_cls()
            except TypeError:
                self._logic = None
        return self._logic


class _ModuleParent:
    """Stand-in for the ``parent`` (qSlicerScriptedLoadableModule) of ScriptedLoadableModule."""

    def __init__(self, name, path):
        self._name = name
        self.path = path
        self.title = name
        self.categories = []
        self.dependencies = []
        self.contributors = []
        self.helpText = ""
        self.acknowledgementText = ""
        self.hidden = False
        self.icon = None
        self.index = 0

    def name(self):
        return self._name

    def setProperty(self, name, value):
        setattr(self, name, value)

    def property(self, name):
        return getattr(self, name, None)

    @builtins.property  # (this class defines a property() method, like QObject)
    def defaultDocumentationLink(self):
        """qSlicerAbstractCoreModule::defaultDocumentationLink"""
        import slicer

        url = slicer.app.moduleDocumentationUrl(self._name)
        return f'<p>For more information see the <a href="{url}">online documentation</a>.</p>'

    def setObjectName(self, name):
        pass

    def objectName(self):
        return self._name


def _parent_info(instance):
    parent = getattr(instance, "parent", None)
    if parent is None:
        return {}
    return {
        "title": getattr(parent, "title", None),
        "categories": list(getattr(parent, "categories", []) or []),
        "dependencies": list(getattr(parent, "dependencies", []) or []),
        "hidden": bool(getattr(parent, "hidden", False)),
        "helpText": getattr(parent, "helpText", "") or "",
        "acknowledgementText": getattr(parent, "acknowledgementText", "") or "",
        "contributors": list(getattr(parent, "contributors", []) or []),
    }


_extension_paths = None


def extension_of_path(path):
    """Name of the extension a module file came from, or None for a module of the application.

    Extension modules are installed into the same directories as the application's own (as in
    desktop Slicer), so what tells them apart is the wheel that brought them: each extension wheel
    records the files it installed.
    """
    global _extension_paths
    if not path:
        return None
    if _extension_paths is None:
        import importlib.metadata

        _extension_paths = {}
        for dist in importlib.metadata.distributions():
            name = (dist.metadata["Name"] or "").replace("_", "-")
            if not name.startswith("slicer-ext-"):
                continue
            for entry in dist.files or []:
                try:
                    _extension_paths[os.path.normpath(str(dist.locate_file(entry)))] = name[len("slicer-ext-"):]
                except Exception:
                    continue
    return _extension_paths.get(os.path.normpath(path))


def forget_extension_paths():
    """Read the installed extensions again (an extension was installed while running)."""
    global _extension_paths
    _extension_paths = None


def extension_python_packages(app):
    """Packages the installed extensions ask the browser for (Pyodide packages such as SciPy).

    An extension says what it needs in its slicerweb-extension.json, which is packaged into its
    wheel; on the desktop it would pip-install them, here they come from the Pyodide distribution
    and are loaded when the extension is installed and when the page starts (see runtime.ts).
    """
    import json

    packages = []
    pattern = os.path.join(app.slicerSharePath, "extensions", "*.json")
    for path in sorted(glob.glob(pattern)):
        try:
            with open(path, encoding="utf8") as handle:
                for name in json.load(handle).get("pythonPackages") or []:
                    if name not in packages:
                        packages.append(name)
        except Exception:
            logger.debug("Extension metadata %s could not be read", path, exc_info=True)
    return packages


_module_icons = {}


def module_icon(name, path=""):
    """The icon a module is known by, as a data URL, or None if it has none.

    Desktop Slicer compiles these into the Qt resources of each module (":/Icons/<Name>.png"). Here
    they are files: the ones of the application and of the extensions are packaged in
    share/Slicer-X.Y/module-icons, and a scripted module may also carry one beside its own file.
    """
    if name in _module_icons:
        return _module_icons[name]

    candidates = []
    try:
        import slicer

        candidates.append(os.path.join(slicer.app.slicerSharePath, "module-icons", name + ".png"))
    except Exception:
        logger.debug("The share directory is not known yet", exc_info=True)
    if path:
        candidates.append(os.path.join(os.path.dirname(path), "Resources", "Icons", name + ".png"))

    icon = None
    for candidate in candidates:
        if not os.path.isfile(candidate):
            continue
        try:
            import base64

            with open(candidate, "rb") as handle:
                icon = "data:image/png;base64," + base64.b64encode(handle.read()).decode("ascii")
            break
        except Exception:
            logger.debug("Icon %s could not be read", candidate, exc_info=True)
    _module_icons[name] = icon
    return icon


def module_share_directory(app, name):
    """vtkSlicerApplicationLogic::GetModuleShareDirectory equivalent for built-in modules."""
    return os.path.join(app.slicerSharePath, "qt-loadable-modules", name)


class ModuleManager:
    """Module registry (qSlicerModuleManager). Qt-style signals: moduleLoaded(QString),
    moduleAboutToBeUnloaded(QString), modulesLoaded(QStringList)."""

    def __init__(self, app):
        self._app = app
        self._slots = {}
        self._modules = {}  # name -> module
        self._descriptors = {}  # name -> descriptor, not yet loaded
        self._modulePaths = []
        self._scripted_sources = {}  # name -> (path)
        # Python modules (packages) missing when a scripted module was imported: {package: [module names]}.
        # The web page loads them (Pyodide packages or PyPI wheels) and loads the modules again.
        self.missingPythonModules = {}
        self._register_builtin_descriptors()

    # ------------------------------------------------------------------ Qt-style signals
    def connect(self, signal, slot):
        self._slots.setdefault(signal.split("(")[0], []).append(slot)
        return True

    def disconnect(self, signal, slot=None):
        name = signal.split("(")[0]
        if slot is None:
            self._slots.pop(name, None)
        elif slot in self._slots.get(name, []):
            self._slots[name].remove(slot)

    def disconnectReceiver(self, receiver):
        """Disconnect the module manager signals of a receiver being destroyed.

        ScriptedLoadableModuleWidget connects to moduleAboutToBeUnloaded() when it is created, so
        without this every module GUI ever built stays alive in this registry.
        """
        from .qtcompat.core import disconnect_receiver

        return disconnect_receiver(self._slots, receiver)

    def _emit(self, name, *args):
        for slot in list(self._slots.get(name, [])):
            try:
                slot(*args)
            except Exception:
                logger.exception("Error in %s handler", name)

    # ------------------------------------------------------------------ registration
    def _register_builtin_descriptors(self):
        from .core_modules import CORE_MODULES

        for descriptor in CORE_MODULES():
            self._descriptors[descriptor.name] = descriptor

    def registerLoadableModule(self, descriptor):
        """Register a loadable module descriptor (used by extensions)."""
        self._descriptors[descriptor.name] = descriptor

    def addModulePath(self, path):
        """Add a directory (or .py file) containing scripted modules (like Slicer's additional module paths)."""
        if path not in self._modulePaths:
            self._modulePaths.append(path)
        # Packages next to scripted modules (e.g. SegmentEditorEffects, SubjectHierarchyPlugins) are
        # importable, as in desktop Slicer
        directory = path if os.path.isdir(path) else os.path.dirname(path)
        if directory not in sys.path:
            sys.path.insert(0, directory)
        for name, filename in _discover_scripted_modules(path).items():
            self._scripted_sources.setdefault(name, filename)

    def _discover_extension_entry_points(self):
        try:
            from importlib.metadata import entry_points
        except ImportError:  # pragma: no cover
            return
        for ep in entry_points(group="slicerweb.modules"):
            try:
                provider = ep.load()
                result = provider() if callable(provider) else provider
            except Exception:
                logger.exception("Failed to load module provider %s", ep.name)
                continue
            for item in result or []:
                if isinstance(item, LoadableModuleDescriptor):
                    self.registerLoadableModule(item)
                elif isinstance(item, str):
                    self.addModulePath(item)

    # ------------------------------------------------------------------ loading
    def loadModules(self, names=None):
        """Load modules (all registered modules if names is None), dependencies first."""
        import slicer

        self._discover_extension_entry_points()
        forget_extension_paths()   # an extension installed since the last load brought new files
        from . import libs

        loadable_dir = libs.loadable_modules_lib_dir()
        if loadable_dir and os.path.isdir(loadable_dir):
            _import_module_python_extensions(loadable_dir)
            if loadable_dir not in sys.path:
                sys.path.append(loadable_dir)  # e.g. vtkvmtk*Python modules of extensions
            self._register_described_loadable_modules(loadable_dir)
        # Python scripted modules of the application and of installed extensions (same folder as the
        # desktop application's lib/Slicer-X.Y/qt-scripted-modules)
        scripted_dir = libs.scripted_modules_lib_dir()
        if scripted_dir and os.path.isdir(scripted_dir):
            self.addModulePath(scripted_dir)
            # Python plugin packages imported at startup by desktop Slicer's Subject Hierarchy and
            # Segmentations modules (their base classes are then importable by name)
            for package in ("SubjectHierarchyPlugins", "SegmentEditorEffects"):
                if package not in sys.modules and os.path.isdir(os.path.join(scripted_dir, package)):
                    try:
                        importlib.import_module(package)
                    except Exception:
                        logger.warning("Python package %s could not be imported", package, exc_info=True)
        self._initializeCoreDisplayableManagers()

        requested = list(names) if names else list(self._descriptors) + list(self._scripted_sources)
        loaded = [name for name in requested if name not in self._modules and self.loadModule(name) is not None]
        host.emit("modules-changed", self.moduleSummaries())
        self._emit("modulesLoaded", loaded)

    def _register_described_loadable_modules(self, directory):
        """Loadable modules of extensions: <Name>.slicerweb-module.json files, written by the SlicerWeb
        extension build instead of the Qt module class (see cmake/UseSlicerWeb.cmake)."""
        import json

        for filename in sorted(glob.glob(os.path.join(directory, "*.slicerweb-module.json"))):
            try:
                with open(filename, encoding="utf8") as f:
                    info = json.load(f)
            except (OSError, ValueError):
                logger.exception("Invalid module description %s", filename)
                continue
            name = info.get("name")
            if not name or name in self._descriptors or name in self._modules:
                continue
            self.registerLoadableModule(LoadableModuleDescriptor(
                name, logicClass=info.get("logicClass") or None, title=info.get("title") or name,
                dependencies=info.get("dependencies") or [], path=filename,
                extension=info.get("extension") or None,
                categories=info.get("categories") or [info.get("extension") or "Extensions"]))

    def _initializeCoreDisplayableManagers(self):
        import slicer

        initializer = getattr(slicer, "vtkSlicerWebCoreModulesInitializer", None)
        if initializer is not None:
            initializer.Initialize()
        else:
            logger.warning("vtkSlicerWebCoreModulesInitializer is not available: module displayable managers are not registered")

    def loadModule(self, name, _stack=()):
        if name in self._modules:
            return self._modules[name]
        if name in _stack:
            raise RuntimeError(f"Circular module dependency: {' -> '.join(_stack + (name,))}")
        descriptor = self._descriptors.get(name)
        if descriptor is None and name in self._scripted_sources:
            try:
                descriptor = self._createScriptedModule(name, self._scripted_sources[name])
            except ModuleNotFoundError as e:
                missing = (e.name or "").split(".")[0]
                if missing and missing not in self._scripted_sources and missing not in self._descriptors:
                    self.missingPythonModules.setdefault(missing, [])
                    if name not in self.missingPythonModules[missing]:
                        self.missingPythonModules[missing].append(name)
                    logger.info("Module %s needs Python package %s, which is not installed yet", name, missing)
                else:
                    logger.exception("Failed to load module %s", name)
                sys.modules.pop(name, None)
                return None
            except Exception:
                logger.exception("Failed to load module %s", name)
                sys.modules.pop(name, None)
                return None
        if descriptor is None:
            logger.warning("Module %s is not available", name)
            return None
        for dep in descriptor.dependencies:
            if dep not in self._modules and (dep in self._descriptors or dep in self._scripted_sources):
                self.loadModule(dep, _stack + (name,))
        try:
            descriptor.initialize(self._app)
        except Exception:
            logger.exception("Failed to initialize module %s", name)
            return None
        self._modules[name] = descriptor
        self._exposeModule(descriptor)
        self._emit("moduleLoaded", name)
        return descriptor

    def _createScriptedModule(self, name, filename):
        import slicer

        directory = os.path.dirname(filename)
        if directory not in sys.path:
            sys.path.insert(0, directory)
        # Libraries next to the module (e.g. <Name>Lib packages) are importable like in desktop Slicer
        _import_module_python_extensions(directory)
        spec = importlib.util.spec_from_file_location(name, filename)
        pythonModule = importlib.util.module_from_spec(spec)
        sys.modules[name] = pythonModule
        spec.loader.exec_module(pythonModule)
        cls = getattr(pythonModule, name, None)
        if cls is None:
            logger.warning("%s does not define class %s", filename, name)
            return None
        import slicer

        if not hasattr(slicer, "selfTests"):
            slicer.selfTests = {}
        parent = _ModuleParent(name, filename)
        instance = cls(parent)
        module = ScriptedModule(name, filename, pythonModule, instance)
        setattr(slicer.modules, name + "Instance", instance)
        return module

    def _exposeModule(self, module):
        import slicer

        setattr(slicer.modules, module.name.lower(), module)
        setattr(slicer.moduleNames, module.name, module.name)

    # ------------------------------------------------------------------ queries
    def module(self, name):
        return self._modules.get(name)

    def modulesNames(self):
        return list(self._modules)

    def moduleSummaries(self):
        return [m.summary() for m in self._modules.values()]

    def factoryManager(self):
        return self

    def loadedModulesNames(self):
        return list(self._modules)

    def registeredModuleNames(self):
        return list(set(self._descriptors) | set(self._scripted_sources))

    def isRegistered(self, name):
        return name in self._descriptors or name in self._scripted_sources

    def isLoaded(self, name):
        return name in self._modules

    # ------------------------------------------------------------------ widgets
    def setWidget(self, name, widget):
        module = self._modules.get(name)
        if module is not None:
            module._widget = widget


def _useWebDeveloperSection():
    """The page's Reload and Test section stands in for the one ScriptedLoadableModuleWidget builds.

    In Developer mode (Developer/DeveloperMode, on by default here), a scripted module's setup()
    ends with setupDeveloperSection(): a Reload & Test collapsible of Qt widgets, with a menu
    button, a button to open the source in an editor and one to restart the application. The page
    shows its own section at the bottom of every scripted module's panel instead
    (ScriptedModuleHost.vue), with what applies here; a module's own developerMode stays what the
    setting says, as on the desktop.
    """
    from slicer.ScriptedLoadableModule import ScriptedLoadableModuleWidget

    if getattr(ScriptedLoadableModuleWidget.setupDeveloperSection, "_slicerweb", False):
        return

    def setupDeveloperSection(self):
        pass

    setupDeveloperSection._slicerweb = True
    ScriptedLoadableModuleWidget.setupDeveloperSection = setupDeveloperSection


def create_scripted_module_widget(moduleName):
    """Create the GUI of a scripted module (ScriptedLoadableModuleWidget.setup() runs unchanged).

    The widget is created in a container that the page can show later, so that module code and tests
    can use slicer.util.getModuleWidget() before the module panel is shown.
    """
    import slicer

    from .qtcompat import mrmlwidgets, widgets

    _useWebDeveloperSection()
    manager = slicer.app.moduleManager()
    module = manager.module(moduleName)
    if module is None or module.kind != "scripted":
        raise KeyError(f"Scripted module {moduleName} is not loaded")
    parent = getattr(module, "_hostWidget", None)
    if parent is not None:
        return module._widget
    parent = mrmlwidgets.qMRMLWidget()
    parent.setLayout(widgets.QVBoxLayout())
    parent.setMRMLScene(slicer.mrmlScene)
    parent.setObjectName(moduleName + "WidgetParent")
    widget_cls = getattr(module.pythonModule, moduleName + "Widget", None)
    if widget_cls is None:
        raise RuntimeError(f"{moduleName} does not define a {moduleName}Widget class")
    instance = widget_cls(parent)
    # An error in setup() leaves the GUI built so far, as on the desktop (the Qt widgets are there
    # already): it is reported, and the page shows it above the GUI (show_scripted_module_widget)
    module._setupError = None
    try:
        instance.setup()
    except Exception as error:
        import traceback

        logger.exception("Error in the setup of module %s", moduleName)
        module._setupError = f"{type(error).__name__}: {error}\n\n{traceback.format_exc()}"
    module._widget = instance
    module._hostWidget = parent
    setattr(slicer.modules, moduleName + "Widget", instance)
    return instance


def show_scripted_module_widget(moduleName, containerSelector):
    """Create (once) and show the GUI of a scripted module inside a container element of the page.

    ScriptedLoadableModuleWidget.setup() runs unchanged; the qt/ctk compatibility layer creates the
    widgets as Slicer web widgets.
    """
    import slicer

    from .qtcompat import dom

    manager = slicer.app.moduleManager()
    module = manager.module(moduleName)
    if module is None or module.kind != "scripted":
        raise KeyError(f"Scripted module {moduleName} is not loaded")
    create_scripted_module_widget(moduleName)
    parent = module._hostWidget
    container = dom.query(containerSelector)
    if container is not None:
        container.appendChild(parent.element())
    _selectedModule[0] = moduleName
    # Selected from Python (select_module), the module has already been entered
    if getattr(module, "_enteredBeforeShown", False):
        module._enteredBeforeShown = False
    elif hasattr(module._widget, "enter"):
        module._widget.enter()
    # what went wrong in setup(), for the page to show above the GUI
    setupError = getattr(module, "_setupError", None)
    return {"setupError": setupError} if setupError else True


_selectedModule = [None]


def select_module(moduleName):
    """Make a module the current one, as slicer.util.selectModule does on the desktop.

    What a module does when it is selected happens now, before this returns - its GUI is made and
    entered - since the code that selects it (a self test, say) goes on to use it at once; the page
    then shows the module's panel.
    """
    import slicer

    module = slicer.app.moduleManager().module(moduleName)
    if module is None:
        raise RuntimeError(f"Module {moduleName} is not loaded")
    if module.kind == "scripted" and _selectedModule[0] != moduleName:
        widget = create_scripted_module_widget(moduleName)
        if hasattr(widget, "enter"):
            widget.enter()
            module._enteredBeforeShown = True
    _selectedModule[0] = moduleName
    host.emit("select-module", {"name": moduleName})


class ModuleSelector:
    """slicer.util.moduleSelector(): the module panel of the page (qSlicerModuleSelectorToolBar)."""

    def selectModule(self, moduleName):
        select_module(moduleName)

    @property
    def selectedModule(self):
        return _selectedModule[0]


def install_module_selector():
    """slicer.util.moduleSelector(), selectModule() and selectedModule() without a main window.

    There is no Qt main window in the browser (slicer.util.mainWindow() is None, which modules
    rely on to leave out desktop-only GUI), so these go to the page's module panel instead.
    """
    import slicer.util

    selector = ModuleSelector()
    slicer.util.moduleSelector = lambda: selector
    # What a scripted module is on the desktop, for isinstance() checks such as that of
    # slicer.util.getModuleLogic (the logic of a scripted module is its widget's)
    import slicer

    slicer.qSlicerScriptedLoadableModule = ScriptedModule


def reload_scripted_module(moduleName):
    """Reload the Python file of a scripted module and rebuild its GUI (slicer.util.reloadScriptedModule)."""
    import slicer

    manager = slicer.app.moduleManager()
    module = manager.module(moduleName)
    if module is None or module.kind != "scripted":
        raise KeyError(f"Scripted module {moduleName} is not loaded")
    filename = module.path
    module.unregisterIO()   # the reloaded module registers its readers and writers again
    destroy_scripted_module_widget(moduleName)
    for name in [moduleName] + [n for n in list(sys.modules) if n.startswith(moduleName + ".")]:
        sys.modules.pop(name, None)
    module._hostWidget = None
    module._widget = None
    manager._modules.pop(moduleName, None)
    manager._scripted_sources[moduleName] = filename
    reloaded = manager.loadModule(moduleName)
    if reloaded is None:
        raise RuntimeError(f"Failed to reload {moduleName}")
    host.emit("modules-changed", manager.moduleSummaries())
    return True


def run_scripted_module_test(moduleName):
    """Run the self test of a scripted module (its <Name>Test class), as "Reload and Test" does."""
    import time
    import traceback

    import slicer

    module = slicer.app.moduleManager().module(moduleName)
    if module is None or module.kind != "scripted":
        raise KeyError(f"Scripted module {moduleName} is not loaded")
    testClass = getattr(module.pythonModule, moduleName + "Test", None)
    if testClass is None:
        raise RuntimeError(f"{moduleName} does not define a {moduleName}Test class")
    test = testClass()
    if hasattr(test, "messageDelay"):
        test.messageDelay = 0  # no message popups in the web page
    start = time.time()
    try:
        test.runTest()
    except Exception as e:
        logger.exception("Test of module %s failed", moduleName)
        return {"passed": False, "message": f"{type(e).__name__}: {e}", "traceback": traceback.format_exc(),
                "seconds": round(time.time() - start, 1)}
    return {"passed": True, "message": "Test passed", "seconds": round(time.time() - start, 1)}


def destroy_scripted_module_widget(moduleName):
    """Take the GUI of a scripted module down for good, before a new one is built.

    The widget observes MRML nodes (and may show its own nodes, e.g. an interactive plane), so it
    keeps working after its GUI is removed from the page: a reloaded module would then have two
    widgets reacting to the same nodes and undoing each other's changes. cleanup() is what the
    module implements for this, as in desktop Slicer's reloadScriptedModule.
    """
    import slicer

    module = slicer.app.moduleManager().module(moduleName)
    widget = getattr(module, "_widget", None) if module else None
    hide_scripted_module_widget(moduleName)
    if widget is not None and hasattr(widget, "cleanup"):
        try:
            widget.cleanup()
        except Exception:
            logger.exception("Cleanup of the %s module GUI failed", moduleName)
    if widget is not None:
        _release_module_widget(widget, parent=getattr(module, "_hostWidget", None))
    if module is not None:
        module._widget = None
        module._hostWidget = None
    if hasattr(slicer.modules, moduleName + "Widget"):
        delattr(slicer.modules, moduleName + "Widget")
    return True


def _release_module_widget(widget, parent=None):
    """Break what the widget and the application hold of each other, after its cleanup().

    cleanup() takes back what the module set up itself (MRML observers, its own nodes). What is left
    are the connections made on its behalf: the application and the module manager keep the slots it
    connected, its GUI elements in the page keep the callbacks that reach it, and the qt objects it
    owns (a timer, for example) keep the methods they call. Each of those is a reference back to the
    widget, so none of it can be collected until they are undone here.
    """
    import slicer

    from .qtcompat.core import QObject

    app = slicer.app
    for holder in (app, app.moduleManager()):
        disconnectReceiver = getattr(holder, "disconnectReceiver", None)
        if disconnectReceiver is not None:
            disconnectReceiver(widget)
    if parent is not None and hasattr(parent, "disconnectReceiver"):
        parent.disconnectReceiver(widget)
    # qt objects the widget owns outlive it only through what they call back into it
    for value in list(vars(widget).values()):
        if isinstance(value, QObject) and value is not parent:
            value.disconnect()
    if parent is not None and hasattr(parent, "_destroy"):
        parent._destroy()


def hide_scripted_module_widget(moduleName):
    import slicer

    module = slicer.app.moduleManager().module(moduleName)
    parent = getattr(module, "_hostWidget", None) if module else None
    if parent is None:
        return False
    if hasattr(module._widget, "exit"):
        module._widget.exit()
    try:
        parent.element().remove()
    except Exception:
        pass
    return True


def _discover_scripted_modules(path):
    """Return {moduleName: filename} of scripted modules in a directory (or a single .py file)."""
    result = {}
    files = [path] if path.endswith(".py") else glob.glob(os.path.join(path, "*.py"))
    for filename in files:
        name = os.path.splitext(os.path.basename(filename))[0]
        if name.startswith("_"):
            continue
        try:
            with open(filename, encoding="utf8") as f:
                text = f.read()
        except OSError:
            continue
        if f"class {name}(ScriptedLoadableModule)" in text or f"class {name}(slicer.ScriptedLoadableModule" in text \
                or f"class {name}(ScriptedLoadableModule.ScriptedLoadableModule)" in text:
            result[name] = filename
    return result


def _import_module_python_extensions(directory):
    """Same as qSlicerScriptedUtils::importModulePythonExtensions (C++ module classes into slicer).

    slicer.util.importVTKClassesFromDirectory remembers the directories it scanned, so it would not
    import libraries installed later (extensions): the files are scanned on each call instead.
    """
    import fnmatch
    import vtk
    from slicer.util import importModuleObjects

    for pattern in ("vtkSlicer*ModuleLogicPython.*", "vtkSlicer*ModuleMRMLPython.*",
                    "vtkSlicer*ModuleMRMLDisplayableManagerPython.*", "vtkSlicer*ModuleVTKWidgetsPython.*",
                    "vtkSlicerWeb*InitializerPython.*"):
        for filename in sorted(glob.glob(os.path.join(directory, pattern))):
            if not fnmatch.fnmatch(os.path.basename(filename), pattern):
                continue
            moduleName = os.path.basename(filename).split(".")[0]
            try:
                importModuleObjects(moduleName, "slicer", vtk.vtkObjectBase)
            except Exception:
                logger.exception("Failed to import %s", moduleName)
