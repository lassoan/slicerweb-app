"""CTK widgets used by Slicer module GUIs."""

from . import dom
from .core import QProp, Signal, count_property
from .types import QColor, QMessageBox
from .widgets import (
    QAbstractButton,
    QAbstractSlider,
    QAbstractSpinBox,
    QCheckBox,
    QComboBox,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QTextBrowser,
    QWidget,
    _ElementWidget,
    _bool,
    _float,
)


class ctkCollapsibleButton(QWidget):
    """Collapsible section. Children are added through its layout (usually a QFormLayout)."""

    _tag = "section"
    _classes = "sw-collapsible mb-1 rounded-md bg-card/60"

    contentsCollapsed = Signal("contentsCollapsed(bool)")
    toggled = Signal("toggled(bool)")
    clicked = Signal("clicked(bool)")

    def __init__(self, text="", parent=None):
        if isinstance(text, QWidget):
            parent, text = text, ""
        self._text = ""
        self._collapsed = False
        super().__init__(parent)
        self.setText(text)

    def _init_element(self):
        self._header = dom.create("button", "flex w-full items-center gap-1.5 rounded-md px-2 py-1.5 text-left text-[13px] font-medium text-foreground hover:bg-accent/60")
        self._header.type = "button"
        self._content = dom.create("div", "flex flex-col gap-1.5 px-2 pt-0.5 pb-2 min-w-0")
        self._el.appendChild(self._header)
        self._el.appendChild(self._content)
        dom.listen(self._header, "click", lambda *a: self.setCollapsed(not self._collapsed))

    def _contentElement(self):
        return self._content

    def _renderHeader(self):
        self._header.textContent = ("▸ " if self._collapsed else "▾ ") + self._text

    def setText(self, text):
        self._text = str(text)
        self._renderHeader()

    text = property(lambda self: self._text, lambda self, v: self.setText(v))

    def setCollapsed(self, collapsed):
        collapsed = bool(collapsed)
        changed = collapsed != self._collapsed
        self._collapsed = collapsed
        try:
            self._content.style.display = "none" if collapsed else ""
        except Exception:
            pass
        self._renderHeader()
        if changed:
            self.contentsCollapsed.emit(collapsed)
            self.toggled.emit(not collapsed)

    collapsed = property(lambda self: self._collapsed, lambda self, v: self.setCollapsed(v))
    checked = property(lambda self: not self._collapsed, lambda self, v: self.setCollapsed(not v))

    def setChecked(self, v):
        self.setCollapsed(not v)

    def isChecked(self):
        return not self._collapsed

    def setCollapsedHeight(self, h):
        pass

    def setContentsFrameShape(self, s):
        pass

    def setButtonTextAlignment(self, a):
        pass


class ctkCollapsibleGroupBox(QGroupBox):
    collapsed = QProp(False)

    def setCollapsed(self, v):
        self.collapsed = v


class ctkSliderWidget(QAbstractSlider):
    pass


class ctkDoubleSlider(QAbstractSlider):
    pass


class ctkDoubleSpinBox(QAbstractSpinBox):
    def setQuantity(self, q):
        pass

    def setMRMLScene(self, scene):
        pass


class ctkRangeWidget(_ElementWidget):
    _tag = "sw-range-slider"
    _classes = ""
    _events = {"valuesChanged": "_onValuesChanged"}

    valuesChanged = Signal("valuesChanged(double,double)")
    minimumValueChanged = Signal("minimumValueChanged(double)")
    maximumValueChanged = Signal("maximumValueChanged(double)")

    minimumValue = QProp(0.0, el="minimumValue", convert=_float)
    maximumValue = QProp(100.0, el="maximumValue", convert=_float)
    minimum = QProp(0.0, el="minimum", convert=_float)
    maximum = QProp(100.0, el="maximum", convert=_float)
    singleStep = QProp(1.0, el="singleStep", convert=_float)
    decimals = QProp(1, el="decimals", convert=int)

    def __init__(self, parent=None):
        super().__init__(parent)
        for name in ("minimum", "maximum", "minimumValue", "maximumValue"):
            dom.set_prop(self._el, name, getattr(self, name))

    def _onValuesChanged(self, lo, hi):
        type(self).minimumValue.set_silently(self, lo)
        type(self).maximumValue.set_silently(self, hi)
        self.valuesChanged.emit(self.minimumValue, self.maximumValue)
        self.minimumValueChanged.emit(self.minimumValue)
        self.maximumValueChanged.emit(self.maximumValue)

    def setValues(self, lo, hi):
        self.minimumValue, self.maximumValue = lo, hi
        self.valuesChanged.emit(self.minimumValue, self.maximumValue)

    def setMinimumValue(self, v):
        self.setValues(v, self.maximumValue)

    def setMaximumValue(self, v):
        self.setValues(self.minimumValue, v)

    def setRange(self, lo, hi):
        self.minimum, self.maximum = lo, hi

    def setMinimum(self, v):
        self.minimum = v

    def setMaximum(self, v):
        self.maximum = v

    def setSingleStep(self, v):
        self.singleStep = v

    def setDecimals(self, v):
        self.decimals = v


class ctkDoubleRangeSlider(ctkRangeWidget):
    positionsChanged = Signal("positionsChanged(double,double)")


class ctkPathLineEdit(_ElementWidget):
    """A file (or folder) for a module to work on.

    A browser has no paths of its own, so the file is chosen with the file picker of the browser
    and copied into the virtual file system; what the module is given is the path it landed on,
    which it can open like any other file (see SwPathLineEdit.vue).
    """

    _tag = "sw-pathlineedit"
    _classes = ""
    _events = {"currentPathChanged": "_onCurrentPathChanged"}

    currentPathChanged = Signal("currentPathChanged(QString)")
    # ctkPathLineEdit::Filters (those of QDir::Filter)
    Dirs, Files, Drives, NoSymLinks = 0x1, 0x2, 0x4, 0x8
    Readable, Writable, Executable, Hidden, System = 0x10, 0x20, 0x40, 0x100, 0x200
    AllDirs, NoDotAndDotDot, NoDot, NoDotDot = 0x400, 0x1000, 0x2000, 0x4000
    AllEntries = Dirs | Files | Drives

    currentPath = QProp("", el="currentPath", signal="currentPathChanged", convert=str)
    nameFilters = QProp([], el="nameFilters")
    placeholderText = QProp("", el="placeholderText", convert=str)
    chooseDirectory = QProp(False, el="chooseDirectory", convert=_bool)
    # A file to be written (the Writable filter): the user names it, and it goes into the documents
    # folder, whose files are offered to the user as downloads (SwPathLineEdit.vue, runtime.ts)
    saveMode = QProp(False, el="saveMode", convert=_bool)
    saveDirectory = QProp("", el="saveDirectory", convert=str)

    def _onCurrentPathChanged(self, path):
        type(self).currentPath.set_silently(self, path)
        self.currentPathChanged.emit(str(path))

    # --- the API of ctkPathLineEdit that module code uses
    def setCurrentPath(self, path):
        self.currentPath = path or ""

    def setNameFilters(self, filters):
        """The kinds of file offered: ``["Mimics project (*.mcs *.mxp)"]``."""
        self.nameFilters = [str(f) for f in (filters or [])]

    def setFilters(self, filters):
        """ctkPathLineEdit::Filters: whether files or folders are wanted, and whether to read or to
        write one. A .ui file gives them by name ("ctkPathLineEdit::Files|ctkPathLineEdit::Writable")."""
        if isinstance(filters, str):
            names = [name.split("::")[-1].strip() for name in filters.split("|")]
            filters = 0
            for name in names:
                filters |= getattr(ctkPathLineEdit, name, 0) if name else 0
        self._filters = int(filters)
        self.chooseDirectory = bool(self._filters & self.Dirs) and not bool(self._filters & self.Files)
        self.saveMode = bool(self._filters & self.Writable) and not self.chooseDirectory
        if self.saveMode:
            import slicer

            self.saveDirectory = slicer.app.defaultScenePath

    # PythonQt exposes Qt properties as attributes, and modules set this one that way
    filters = property(lambda self: getattr(self, "_filters", ctkPathLineEdit.Files), setFilters)


    def setSettingKey(self, key):
        """Where the last path would be remembered; nothing is remembered here."""

    def setShowHistoryButton(self, v):
        pass

    def setShowBrowseButton(self, v):
        pass

    def addCurrentPathToHistory(self):
        pass

    def retrieveHistory(self):
        pass

    # ctkPathLineEdit is a line edit as well: text and currentPath are the same thing
    @property
    def text(self):
        return self.currentPath

    @text.setter
    def text(self, value):
        self.currentPath = value

    def setText(self, value):
        self.currentPath = value


class ctkDirectoryButton(ctkPathLineEdit):
    directoryChanged = Signal("directoryChanged(QString)")

    def __init__(self, parent=None):
        super().__init__(parent)
        self.chooseDirectory = True
        self.currentPathChanged.connect(self.directoryChanged.emit)

    # ctkDirectoryButton::directory is the folder that was chosen
    directory = property(lambda self: self.currentPath, lambda self, v: self.setCurrentPath(v))


class ctkComboBox(QComboBox):
    def setDefaultText(self, text):
        pass

    def setDefaultIcon(self, icon):
        pass


class _CheckableModelIndex:
    """An index of ctkCheckableComboBox's model: the row of an item."""

    def __init__(self, row, column=0):
        self._row, self._column = int(row), int(column)

    def row(self):
        return self._row

    def column(self):
        return self._column

    def isValid(self):
        return self._row >= 0


class _CheckableModel:
    def __init__(self, combo):
        self._combo = combo

    def index(self, row, column=0, *args):
        return _CheckableModelIndex(row, column)

    def rowCount(self, *args):
        return self._combo.count


class ctkCheckableComboBox(QComboBox):
    """A combo box whose items are checked on and off, each with its own check state. The state is
    kept per item; the list does not show check boxes yet, so it is set from code."""

    checkedIndexesChanged = Signal("checkedIndexesChanged()")

    def _states(self):
        if not hasattr(self, "_checkStates"):
            self._checkStates = {}
        return self._checkStates

    def checkableModel(self):
        return _CheckableModel(self)

    def model(self):
        return self.checkableModel()

    def checkState(self, index):
        from .types import Qt

        return self._states().get(index.row(), Qt.Unchecked)

    def setCheckState(self, index, state):
        from .types import Qt

        row = index.row()
        state = int(state)
        if self._states().get(row, Qt.Unchecked) != state:
            self._states()[row] = state
            self.checkedIndexesChanged.emit()

    def checkedIndexes(self):
        from .types import Qt

        return [_CheckableModelIndex(r) for r, s in sorted(self._states().items()) if s == Qt.Checked]

    def allChecked(self):
        return len(self.checkedIndexes()) == self.count

    def noneChecked(self):
        return not self.checkedIndexes()


class ctkColorPickerButton(_ElementWidget):
    _tag = "sw-colorpicker"
    _classes = ""
    _events = {"colorChanged": "_onColorChanged"}

    colorChanged = Signal("colorChanged(QColor)")
    ShowColorName, UseCTKColorDialog = 1, 2

    def __init__(self, *args):
        parent = next((a for a in args if isinstance(a, QWidget)), None)
        super().__init__(parent)
        self._color = QColor(255, 255, 255)
        text = next((a for a in args if isinstance(a, str)), "")
        if text:
            dom.set_prop(self._el, "text", text)

    def _onColorChanged(self, value):
        self._color = QColor(value)
        self.colorChanged.emit(self._color)

    def setColor(self, color):
        self._color = color if isinstance(color, QColor) else QColor(color)
        dom.set_prop(self._el, "color", self._color.name())
        self.colorChanged.emit(self._color)

    color = property(lambda self: self._color, lambda self, v: self.setColor(v))

    def setDisplayColorName(self, v):
        pass

    def setDialogOptions(self, o):
        pass


class ctkPushButton(QPushButton):
    """ctkPushButton: QPushButton with icon/text alignment options (alignment is not used here)."""

    def setButtonTextAlignment(self, alignment):
        pass

    def setIconAlignment(self, alignment):
        pass


class ctkCheckablePushButton(QPushButton):
    """Push button with its own check box (e.g. "Apply" with an auto-update option).

    The check box is a separate control inside the button: clicking it switches the option
    (checkBoxToggled) without running the button's action (clicked). The check box also sets the
    button's checked state, unless setCheckBoxControlsButtonToggleState(False) is called.
    """

    checkBoxToggled = Signal("checkBoxToggled(bool)")

    _events = dict(QPushButton._events, checkBoxToggled="_onCheckBoxToggled")

    # the check box shows the checked state (the button itself is not highlighted)
    checked = QProp(False, el="checkBoxChecked", convert=_bool)

    def __init__(self, text="", parent=None, *args):
        super().__init__(text, parent, *args)
        self._checkBoxVisible = True
        self._checkBoxControlsButton = True
        self._checkBoxControlsButtonToggleState = True
        dom.set_prop(self._el, "checkBoxVisible", True)

    def _onCheckBoxToggled(self, checked):
        checked = bool(checked)
        if self._checkBoxControlsButtonToggleState:
            type(self).checked.set_silently(self, checked)
            dom.set_prop(self._el, "checkBoxChecked", checked)
        self.checkBoxToggled.emit(checked)
        if self._checkBoxControlsButtonToggleState:
            self.toggled.emit(checked)

    def setCheckBoxVisible(self, visible):
        self._checkBoxVisible = bool(visible)
        dom.set_prop(self._el, "checkBoxVisible", self._checkBoxVisible)

    def isCheckBoxVisible(self):
        return self._checkBoxVisible

    def setCheckBoxControlsButton(self, enabled):
        self._checkBoxControlsButton = bool(enabled)

    def checkBoxControlsButton(self):
        return self._checkBoxControlsButton

    def setCheckBoxControlsButtonToggleState(self, enabled):
        self._checkBoxControlsButtonToggleState = bool(enabled)

    def checkBoxControlsButtonToggleState(self):
        return self._checkBoxControlsButtonToggleState

    def setCheckState(self, state):
        self.setChecked(bool(state))

    # A Qt property (PythonQt: button.checkState == qt.Qt.Checked, button.checkState = ...), which
    # can also be called
    checkState = count_property(lambda self: 2 if self.isChecked() else 0, lambda self, state: self.setCheckState(state))

    def setIndicatorAlignment(self, alignment):
        """Which edge of the button the check box is at: the left one (Qt.AlignLeft, CTK's default)
        or the right one (Qt.AlignRight). A .ui file gives the flags as text (Qt::AlignRight|...)."""
        if isinstance(alignment, str):
            right = "AlignRight" in alignment
        else:
            right = bool(int(alignment) & 0x2)
        self._indicatorAlignment = 0x2 if right else 0x1
        dom.set_prop(self._el, "checkBoxAlignment", "right" if right else "left")

    def indicatorAlignment(self):
        return getattr(self, "_indicatorAlignment", 0x1)


class ctkCheckBox(QCheckBox):
    """ctkCheckBox: a check box whose indicator can be styled (the same control here)."""

    def setIndicatorIcon(self, icon):
        pass


class ctkMenuButton(QPushButton):
    """A button with a menu of its own from the start, as ctkMenuButton has: modules add their options
    to menu() right away. The menu is not shown on the button yet; its actions keep their state."""

    def __init__(self, *args):
        super().__init__(*args)
        from .widgets import QMenu

        self.setMenu(QMenu(self))


class ctkSearchBox(QLineEdit):
    pass


class ctkFittedTextBrowser(QTextBrowser):
    pass


class ctkFlowLayout(QHBoxLayout):
    """A layout whose widgets are placed side by side and wrap to the next line when the room
    runs out (the Sample Data module lays its thumbnails out this way)."""

    _classes = "flex flex-row flex-wrap items-start gap-1.5 min-w-0"

    # Which way it is allowed to grow; nothing to do here, the wrapping does it (ctkFlowLayout
    # takes this as a Qt property).
    preferredExpandingDirections = None

    def setPreferredExpandingDirections(self, directions):
        self.preferredExpandingDirections = directions

    def setAlignItems(self, align):
        pass


class ctkExpandableWidget(QWidget):
    pass


class ctkCoordinatesWidget(QWidget):
    coordinatesChanged = Signal("coordinatesChanged(double*)")

    def __init__(self, parent=None):
        super().__init__(parent)
        from .widgets import QDoubleSpinBox, QHBoxLayout

        layout = QHBoxLayout(self)
        self._boxes = []
        for i in range(3):
            box = QDoubleSpinBox()
            box.setRange(-1e6, 1e6)
            box.valueChanged.connect(lambda *a: self.coordinatesChanged.emit(self.coordinates))
            layout.addWidget(box)
            self._boxes.append(box)

    coordinates = property(lambda self: ",".join(str(b.value) for b in self._boxes),
                           lambda self, v: self.setCoordinates(v))

    def setCoordinates(self, *values):
        if len(values) == 1 and isinstance(values[0], str):
            values = [float(v) for v in values[0].split(",")]
        elif len(values) == 1:
            values = list(values[0])
        for b, v in zip(self._boxes, values):
            b.setValue(v)

    def setDecimals(self, d):
        for b in self._boxes:
            b.setDecimals(d)

    def setMinimum(self, v):
        for b in self._boxes:
            b.setMinimum(v)

    def setMaximum(self, v):
        for b in self._boxes:
            b.setMaximum(v)

    def setSingleStep(self, s):
        for b in self._boxes:
            b.setSingleStep(s)


class ctkVTKSliceView(QWidget):
    pass


def _message_line(value):
    """A line of a message box: what it holds, or what it answers when it is a method (windowTitle)."""
    text = value() if callable(value) else value
    return str(text) if text else ""


class ctkMessageBox(QWidget):
    """A message box with a "Don't show again" check box, which Slicer uses for everything it tells
    the user (slicer.util.messageBox and confirmOkCancelDisplay make one of these). What it is given
    has to reach the user, so here it is the browser's own dialog, as QMessageBox uses.
    """

    def __init__(self, parent=None, *args, **kwargs):
        super().__init__(parent, *args, **kwargs)
        self.text = ""
        self.informativeText = ""
        self.detailedText = ""
        self.icon = QMessageBox.NoIcon
        self.standardButtons = QMessageBox.Ok
        self.dontShowAgain = False

    def setText(self, text):
        self.text = text

    def setInformativeText(self, text):
        self.informativeText = text

    def setDetailedText(self, text):
        self.detailedText = text

    def setIcon(self, icon):
        self.icon = icon

    def setStandardButtons(self, buttons):
        self.standardButtons = buttons

    def setDefaultButton(self, button):
        self._defaultButton = button

    def setDontShowAgainVisible(self, visible):
        self._dontShowAgainVisible = visible

    def setDontShowAgainSettingsKey(self, key):
        self._dontShowAgainSettingsKey = key

    def exec_(self):
        # The details, which the desktop shows under "Show Details...", are part of the message here
        parts = (self.windowTitle, self.text, self.informativeText, self.detailedText)
        # (stripped: slicer.util.messageBox pads the title with spaces to make the desktop dialog wider)
        message = "\n\n".join(t for t in (_message_line(part).strip() for part in parts) if t)
        # A box that offers a way out is a question, and the browser has one of those too
        asks = self.standardButtons & (QMessageBox.Cancel | QMessageBox.No)
        if asks:
            accepted = QMessageBox._confirm(message)
            if accepted:
                return QMessageBox.Yes if self.standardButtons & QMessageBox.Yes else QMessageBox.Ok
            return QMessageBox.No if self.standardButtons & QMessageBox.No else QMessageBox.Cancel
        QMessageBox._alert(message)
        return QMessageBox.Ok

    exec = exec_
