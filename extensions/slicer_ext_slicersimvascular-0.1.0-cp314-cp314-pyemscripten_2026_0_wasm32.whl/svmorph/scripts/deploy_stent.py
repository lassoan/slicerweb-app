"""SDF-contact stent deployment script.

Deploys a crimped stent inside a vascular surface mesh until the stent
radius reaches a prescribed target, using the SDF-contact Kelvinlet
deformation routine.

.. note::

   ``--start-R`` must be smaller than the local vessel radius at the
   deployment site so the stent begins fully inside the lumen.  A value
   of 0.05 cm works well for typical cardiovascular geometries.

Usage::

    python -m svmorph.scripts.deploy_stent \\
        --mesh surface.vtp --cline centerline.vtp \\
        --start 123 --target-R 0.4 --start-R 0.05 \\
        --length 3.0 --save-step 0.1 \\
        --out-mesh deployed_surface.vtp --out-cl deployed_centerline.vtp
"""

from __future__ import annotations

import argparse
import time

import numpy as np

from svmorph.core import deformation, geometry, mesh_data
from svmorph.core.units import L
from svmorph.logging import get_logger
from svmorph.scripts import common

logger = get_logger(__name__)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Deploy a crimped stent via SDF-contact Kelvinlet deformation.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    common.add_common_args(parser)
    parser.add_argument(
        "--start", type=int, required=True,
        help="Centerline point ID for stent distal tip",
    )
    parser.add_argument("--target-R", type=float, default=None, help="Target deployed stent radius (default: 0.4 cm)")
    parser.add_argument("--start-R", type=float, default=None, help="Initial crimped stent radius (default: 0.05 cm)")
    parser.add_argument("--length", type=float, default=None, help="Stent length along centerline (default: 1.7 cm)")
    parser.add_argument(
        "--flare-R", type=float, default=None,
        help="Optional flared (funnel/trumpet) end: stent radius at the tip of the flared end "
             "(default: no flare)",
    )
    parser.add_argument(
        "--flare-length", type=float, default=None,
        help="Length of the flare radius transition along the stent axis (default: 0.5 cm)",
    )
    parser.add_argument(
        "--flare-end", choices=("start", "end"), default="end",
        help="Which end of the stent axis is flared: 'start' is the --start point side, "
             "'end' is the opposite (proximally resampled) side",
    )
    parser.add_argument(
        "--cap-height-fraction", type=float, default=1.0,
        help="Axial height of the capsule end caps as a fraction of the local stent radius; "
             "1.0 keeps the classic spherical caps, smaller values (e.g. 0.35) flatten them "
             "into half ellipsoids, recommended for flared or concave radius profiles",
    )
    parser.set_defaults(out_mesh="deployed_surface.vtp", out_cl="deployed_centerline.vtp")
    return parser


def main(argv: list[str] | None = None) -> None:
    args = build_parser().parse_args(argv)
    common.setup_logging(args)

    if args.target_R is None:
        args.target_R = 0.4 * L()
    if args.start_R is None:
        args.start_R = 0.05 * L()
    if args.length is None:
        args.length = 1.7 * L()

    smoothing_k = 0.01 * L()

    logger.info("Loading simulation data...")
    ctx = common.load_simulation_data(args.mesh, args.cline)
    deformation.set_node_indices(ctx.data, [args.start])
    deformation.set_force_center(ctx.data, args.start)

    foreshortening = 0.1
    deployed_length = args.length * (1 - foreshortening)
    axis_pts = geometry.resample_stent_axis(
        ctx.data["points"]["centerline_points_view_np"],
        ctx.parent_tip_map,
        ctx.segment_base_mask,
        args.start,
        deployed_length,
        0.1 * L(),
        sampling_direction=-1,
    )
    logger.info(f"Stent axis: {len(axis_pts)} vertices over {deployed_length:.2f}")

    # Optional flared end: per-vertex radius profile as fractions of the nominal target
    # radius, so the whole profile can be scaled proportionally during deployment
    radius_profile_fractions = None
    if args.flare_R is not None:
        if args.flare_length is None:
            args.flare_length = 0.5 * L()
        target_radii = geometry.flared_stent_radius_profile(
            np.asarray(axis_pts), args.target_R, args.flare_R, args.flare_length,
            flare_at_axis_start=(args.flare_end == "start"),
        )
        radius_profile_fractions = target_radii / args.target_R
        logger.info(
            f"Flared '{args.flare_end}' end: radius {args.target_R:.4f} -> {args.flare_R:.4f} "
            f"over {args.flare_length:.2f}"
        )

    a, b = mesh_data.compute_material_constants(1.0, 0.2)

    snapshots = common.SnapshotManager(
        start_value=args.start_R,
        target_value=args.target_R,
        save_step=args.save_step,
        out_mesh_path=args.out_mesh,
        out_cl_path=args.out_cl,
        surface_pd=ctx.surface_pd,
        centerline_pd=ctx.centerline_pd,
        data=ctx.data,
    )

    cur_R = args.start_R - smoothing_k
    logger.info(f"Starting R = {args.start_R:.4f}, target R = {args.target_R:.4f}")

    iteration = 0
    t0 = time.time()
    while True:
        if radius_profile_fractions is None:
            current_stent_radius = cur_R
            bounding_stent_radius = args.target_R
        else:
            # Scale the whole radius profile proportionally with the nominal radius, keeping
            # the smooth-min smoothing offset constant along the stent
            current_stent_radius = radius_profile_fractions * (cur_R + smoothing_k) - smoothing_k
            bounding_stent_radius = float(radius_profile_fractions.max()) * args.target_R
        surf_disp, cl_disp, dR = deformation.compute_sdf_contact_displacements(
            ctx.data,
            axis_pts,
            s=-1.0,
            target_stent_radius=bounding_stent_radius,
            current_stent_radius=current_stent_radius,
            cap_height_fraction=args.cap_height_fraction,
        )
        if cur_R + dR > args.target_R:
            logger.info("Next increment would overshoot target -- done.")
            break
        mesh_data.apply_displacements(ctx.data, surf_disp, "surface")
        mesh_data.apply_displacements(ctx.data, cl_disp, "centerline")
        cur_R += dR
        iteration += 1
        displayed_R = cur_R + smoothing_k
        logger.info(f"Step {iteration:3d}: dR={dR:.5f}  R={displayed_R:.5f}")
        snapshots.check_and_save(displayed_R)

    elapsed = time.time() - t0
    logger.info(f"Deployment complete: {iteration} steps in {elapsed:.2f} s")
    common.save_final(ctx, args)


if __name__ == "__main__":
    main()
